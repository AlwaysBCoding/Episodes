.. ref_config:

================
Config Reference
================

botocore.config
---------------

.. autoclass:: botocore.config.Config
   :members: