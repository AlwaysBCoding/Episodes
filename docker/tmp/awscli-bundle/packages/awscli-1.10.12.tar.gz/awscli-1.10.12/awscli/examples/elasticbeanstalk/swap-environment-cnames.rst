**To swap environment CNAMES**

The following command swaps the assigned subdomains of two environments::

  aws elasticbeanstalk swap-environment-cnames --source-environment-name my-env-blue --destination-environment-name my-env-green
