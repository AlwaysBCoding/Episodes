The following command waits until a cluster with the cluster ID ``j-3SD91U2E1L2QX`` is up and running::

  aws emr wait cluster-running --cluster-id j-3SD91U2E1L2QX
