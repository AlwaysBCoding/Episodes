**To get the per-region list of REST APIs**

Command::

  aws apigateway get-rest-apis --region us-west-2

Output::

  {
      "items": [
          {
              "createdDate": 1438884790, 
              "id": "12s44z21rb", 
              "name": "My First API"
          }
      ]
  }

