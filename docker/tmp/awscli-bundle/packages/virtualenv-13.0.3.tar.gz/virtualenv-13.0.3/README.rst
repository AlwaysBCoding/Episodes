virtualenv
==========

.. image:: https://pypip.in/v/virtualenv/badge.png
        :target: https://pypi.python.org/pypi/virtualenv

.. image:: https://secure.travis-ci.org/pypa/virtualenv.png?branch=develop
   :target: http://travis-ci.org/pypa/virtualenv

For documentation, see https://virtualenv.pypa.io/
